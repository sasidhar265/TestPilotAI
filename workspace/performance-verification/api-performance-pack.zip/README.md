# JMETER test pack

Case coverage: TC-HEALTH-001.

Input/CaseData.Json retains selected cases; Input/TestData.Json retains mappings.
Reqnroll contains runner configuration; Features contains the executable checks.
StepDefinitions, Hooks, TestContext, Builders and Models are unused by these native script packs. Utilities contains measured reporting; browser Services contains journey execution. No BDD runtime or Playwright is required.

## Run with Apache JMeter 5.6.3 or compatible

Set host, protocol and port in Reqnroll/jmeter.properties. Run from the pack root:

```sh
jmeter -n -t Features/performance.jmx -q Reqnroll/jmeter.properties -l TestResults/Reports/results.jtl -j TestResults/Reports/jmeter.log -e -o TestResults/Reports/html
```

Use a fresh JTL file and empty HTML output directory for each run. Review failed samples in the JTL and HTML report; JMeter process success alone does not mean assertions passed. The duration assertion is a per-response limit, not a percentile SLA. Each thread executes the supplied cases sequentially for the configured iteration count. Redirects are not followed. Add environment-specific authentication, correlation and pacing where the journey requires them.
https://jmeter.apache.org/usermanual/get-started.html

## Recommended runner with CI gates (Python 3.11+)

Set TARGET_BASE_URL; optionally JMETER_BIN and JMETER_PRIVATE_PROPERTIES for private authentication properties. Run `python Reqnroll/run.py`. The runner creates a unique timestamped results directory, JTL, JMeter dashboard and the shared measured report. Duration mode supersedes iterations.

## Workload, evidence and acceptance

Input/PerformanceConfig.Json records workload and supplied budgets. No organisation SLA is inferred: p95/p99 gates are optional until supplied. The default error budget is zero and minimum samples is one; select business-approved budgets and adequate sample counts for your environment. Warm-up samples remain in raw data but are excluded from the shared summary. JMeter's dashboard includes all raw samples. Review per-case p50/p90/p95/p99, min/mean/max, throughput and error rate. Failures count in latency percentiles. Missing/insufficient samples fail the gate. The runner exits nonzero on tool, assertion or SLA failure. Reports include samples.json, summary.json, summary.csv and report.html.

Use smoke, baseline, load, stress and soak runs with explicitly chosen load levels. Record deployment/version, environment, dataset, test window, generator capacity and server CPU/memory/DB/queue telemetry alongside the report. Correlate spikes with application traces. Repeat baselines under comparable conditions. Authentication setup, business data and API token/ID correlation must come from the actual contract; they are not fabricated by this generator.
