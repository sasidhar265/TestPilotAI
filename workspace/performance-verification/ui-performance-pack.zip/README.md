# BROWSER test pack

Case coverage: TC-UI-LOGIN-001.

Input/CaseData.Json retains selected cases; Input/TestData.Json retains mappings.
Reqnroll contains runner configuration; Features contains the executable checks.
StepDefinitions, Hooks, TestContext, Builders and Models are unused by these native script packs. Utilities contains measured reporting; browser Services contains journey execution. Playwright Chromium is required; no BDD runtime is required.

## Real-browser performance (Python 3.11+)

Install `python -m pip install -r requirements.txt` and `python -m playwright install chromium`. Set TARGET_BASE_URL to the actual origin and run `python Features/browser-performance.py`. Each isolated browser user runs the supplied actions and waits for your explicit ready selector. Optional BROWSER_STORAGE_STATE points to a private authenticated Playwright state file; action value_env reads secrets from runtime environment. Do not put credentials in Input. Journey timing includes navigation, actions and readiness. Samples include TTFB, DOMContentLoaded, load and available FCP timings. These are observed browser timings, not Lighthouse scores or field Core Web Vitals. Browser users share this load generator: monitor its CPU/memory. Maximum 50 users.

## Workload, evidence and acceptance

Input/PerformanceConfig.Json records workload and supplied budgets. No organisation SLA is inferred: p95/p99 gates are optional until supplied. The default error budget is zero and minimum samples is one; select business-approved budgets and adequate sample counts for your environment. Warm-up samples remain in raw data but are excluded from the shared summary. JMeter's dashboard includes all raw samples. Review per-case p50/p90/p95/p99, min/mean/max, throughput and error rate. Failures count in latency percentiles. Missing/insufficient samples fail the gate. The runner exits nonzero on tool, assertion or SLA failure. Reports include samples.json, summary.json, summary.csv and report.html.

Use smoke, baseline, load, stress and soak runs with explicitly chosen load levels. Record deployment/version, environment, dataset, test window, generator capacity and server CPU/memory/DB/queue telemetry alongside the report. Correlate spikes with application traces. Repeat baselines under comparable conditions. Authentication setup, business data and API token/ID correlation must come from the actual contract; they are not fabricated by this generator.
